# fenv/__init__.py

"""Do math with your own functions.

Modules exported by this package:

- `fenv`: Create virtualenv fast"""
